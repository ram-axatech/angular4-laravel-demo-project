import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  public userForm: FormGroup;
  public users;
  public bViewActive = true;
  private iLoopVar: number;
  public error_msg ;

  constructor(
    private fb: FormBuilder, private userService: UserService
  ) {
      this.userForm = fb.group({
        name: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        role: ['admin', [Validators.required]],
        id: ''
      });
   }

  ngOnInit() {
    // valid login and role validations comes here
    this.userService.users().subscribe((response) => {
      this.users = response;
    });

    this.bViewActive = false;
  }

  save() {
    this.bViewActive = true;
    let oData = this.userForm.value;
    if (oData.id !== '' && oData.id > 0) {
      this.update(oData);
    } else { // insert request
      this.create(oData);
    }
  }

  update(oData) {
    this.userService.update(oData).subscribe((response) => {
      if (response['status']) {
        this.users[this.iLoopVar] = oData;
      } else {
        this.error_msg = response['msg'];
      }
      this.reset();
      this.bViewActive = false;
    });
  }

  create(oData) {
    this.userService.create(oData).subscribe((response) => {
      if (response['status']) {
        oData.id = response['id'];
        this.users.push(oData);
        this.reset();
      } else {
        this.error_msg = response['msg'];
      }
      this.bViewActive = false;
    });
  }

  edit(user, i: number) {
    this.iLoopVar = i;
    this.bViewActive = false;
    this.userForm.setValue({
      name: user.name,
      email: user.email,
      role: user.role,
      password: '',
      id: user.id
    });
  }

  view(user) {
    this.bViewActive = true;
    this.userForm.setValue({
      name: user.name,
      email: user.email,
      role: user.role,
      password: '',
      id: user.id
    });
  }

  delete(user, i: number) {
    this.iLoopVar = i;
    this.userService.delete(user.id).subscribe((response) => {
      this.users.splice(i, 1);
      this.reset();
      this.bViewActive = false;
    });
  }

  reset() {
    this.userForm.setValue({
      name: '',
      email: '',
      role: '',
      password: '',
      id: ''
    });
  }
}
