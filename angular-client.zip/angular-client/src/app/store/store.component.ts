import { Component, OnInit, Output, EventEmitter, AfterContentInit } from '@angular/core';
import { Router } from '@angular/router';
import { ShoppingService } from '../services/shopping.service';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})
export class StoreComponent implements OnInit, AfterContentInit {

  public products;
  public cartText;
  constructor(
    private router: Router, private sp: ShoppingService,
    private login: LoginService
  ) {
    this.cartText = 'Your Cart Is Empty';
  }

  ngOnInit() {
    this.login.initUser();
    this.sp.initCart();
    this.cartText = this.sp.getCartText();
    this.sp.getProducts().subscribe((response) => {
        this.products = response;
    });
  }

  ngAfterContentInit() {
    this.login.loginEvent.emit();
  }

  addToCart(product) {
    this.sp.addToCart(product);
    this.cartText = this.sp.getCartText();
  }

  viewCart() {
    this.router.navigate(['/shopping']);
  }

}
