import { Injectable } from '@angular/core';
import { Config } from './config';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ShoppingService {
  private cartItems =  {};
  private cartKey = 'cart-details';
  constructor(private http: HttpClient, private config: Config) { }

  getProducts() {
    return this.http.get(this.config.URL + 'api/store');
  }

  addToCart(product) {
    this.cartItems[product.id] = product;
    this.updateStorage();
  }

  updateStorage() {
    localStorage.setItem(this.cartKey, JSON.stringify(this.cartItems));
  }

  initCart() {
    let items = localStorage.getItem(this.cartKey);
    if (items) {
      this.cartItems = JSON.parse(items);
    }
  }

  getCartText(): string {
    let text = 'Your Cart Is Empty';
    let itemCount = Object.keys(this.cartItems).length;
    if (itemCount > 0) {
      text = 'Your cart contains ';
      text = text + itemCount;
      text += (itemCount > 1) ? ' items' : ' item';
    }
    return text;
  }

  getCartItems() {
    return Object.values(this.cartItems);
  }

  removeCartItem(product) {
    delete this.cartItems[product.id];
    this.updateStorage();
  }

}
