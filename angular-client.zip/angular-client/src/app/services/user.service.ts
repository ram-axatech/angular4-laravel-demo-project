import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Config } from './config';
import { LoginService } from './login.service';

@Injectable()
export class UserService {

  constructor(
    private http: HttpClient, private config: Config,
    private login: LoginService
  ) { }

  users() {
    return this.http.get(
      this.config.URL + 'api/users/' + this.login.getUserId()
    );
  }

  create(params) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/users/';
    return this.http.post(url, params);
  }

  update(params) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/users/' + params.id;
    return this.http.put(url, params);
  }

  delete(id) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/users/' + id;
    return this.http.delete(url);
  }

}
