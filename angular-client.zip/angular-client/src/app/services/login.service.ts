import { Injectable, EventEmitter } from '@angular/core';
import { Config } from './config';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class LoginService {

  private bIsAdminLogin = false;
  private bIsLoggedIn = false;
  private username = '';
  private loginKey = 'credentials';
  private user;
  public loginEvent = new EventEmitter<any>();

  constructor(private http: HttpClient, private config: Config) {
  }

  isLoggedIn(): boolean {
    return this.bIsLoggedIn;
  }

  isAdminLogin(): boolean {
    return this.bIsAdminLogin;
  }

  authenticate(params) {
    let url = this.config.URL + 'api/login';
    return this.http.post(url, params);

  }

  validateLogin(params): boolean {
    this.bIsLoggedIn = true;
    return this.bIsLoggedIn;
  }

  verifyLogin(): boolean {
    return false;
  }

  createSession(params) {
    localStorage.setItem(this.loginKey, JSON.stringify(params));
  }

  destroySession() {
    localStorage.removeItem(this.loginKey);
    this.initUser();
  }

  initUser() {
    this.bIsAdminLogin = false;
    this.bIsLoggedIn = false;
    this.user = localStorage.getItem(this.loginKey);
    if (this.user) {
      this.bIsLoggedIn = true;
      this.user = JSON.parse(this.user);
      if (this.user['role'] === 'admin') {
        this.bIsAdminLogin = true;
      }
    }
  }

  getUserId() {
    return this.user['id'];
  }

  getUserName() {
    if (this.user) {
      return this.user['name'];
    } else {
      return '';
    }
  }

}
