import { Component, OnInit } from '@angular/core';
import { ShoppingService } from '../services/shopping.service';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  public cartText;
  public products;
  public iTotal = 0;
  public componentTitle;
  constructor(
    private sp: ShoppingService, private login: LoginService
  ) { }

  ngOnInit() {
    this.componentTitle = 'Please login/signup before to place the order';
    console.log(this.login.isLoggedIn());
    if (this.login.isLoggedIn()) {
      this.componentTitle = 'One Page Checkout feature coming soon.';
    }
    this.sp.initCart();
    this.refresh();
  }

  refresh() {
    this.cartText = this.sp.getCartText();
    this.products = this.sp.getCartItems();
    this.iTotal = this.getTotal();
  }

  getTotal() {
    let iTotal = 0;
    for (let i = 0; i < this.products.length; i++) {
      // tslint:disable-next-line:radix
      iTotal += parseInt(this.products[i]['price']);
    }
    return iTotal;
  }

  removeProduct(product) {
    this.sp.removeCartItem(product);
    this.refresh();
  }

}
