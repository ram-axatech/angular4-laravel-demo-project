import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgForm, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { UserComponent } from './user/user.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { StoreComponent } from './store/store.component';
import { RegisterComponent } from './register/register.component';

import { LoginService } from './services/login.service';
import { UserService } from './services/user.service';
import { Config } from './services/config';
import { ProductService } from './services/product.service';
import { ShoppingService } from './services/shopping.service';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProductsComponent,
    UserComponent,
    ShoppingCartComponent,
    StoreComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: StoreComponent },
      { path: 'login', component: LoginComponent },
      { path: 'signup', component: RegisterComponent },
      { path: 'products', component: ProductsComponent },
      { path: 'user', component: UserComponent },
      { path: 'shopping', component: ShoppingCartComponent },
      { path: 'store', component: StoreComponent },
      { path: '**', component: StoreComponent }
    ])
  ],
  providers: [
    LoginService,
    UserService,
    ProductService,
    ShoppingService,
    Config
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
