import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Config } from './config';
import { LoginService } from './login.service';

@Injectable()
export class ProductService {

  constructor(
    private http: HttpClient, private config: Config,
    private login: LoginService
  ) { }

  products() {
    return this.http.get(
      this.config.URL + 'api/products/' + this.login.getUserId()
    );
  }
  
  create(params) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/products/';
    return this.http.post(url, params);
  }

  update(params) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/products/' + params.id;
    return this.http.put(url, params);
  }

  delete(id) {
    // tslint:disable-next-line:prefer-const
    let url = this.config.URL + 'api/products/' + id;
    return this.http.delete(url);
  }

}
