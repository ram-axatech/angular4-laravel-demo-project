import { Component, OnInit } from '@angular/core';
import { LoginService } from './services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Shopping Cart Angular4';
  bIsLoggedIn: boolean;
  bIsAdminLogin: boolean;
  username: string;

  constructor(private login: LoginService, private router: Router) {
    this.login.loginEvent.subscribe(() => {
      this.refresh();
    });
  }

  ngOnInit() {
    this.login.initUser();
    this.refresh();
  }

  refresh() {
    this.bIsLoggedIn = this.login.isLoggedIn();
    this.bIsAdminLogin = this.login.isAdminLogin();
    this.username = this.login.getUserName();
  }

  logout() {
    this.login.destroySession();
    this.login.loginEvent.emit();
    this.router.navigateByUrl('/store');
  }


}
