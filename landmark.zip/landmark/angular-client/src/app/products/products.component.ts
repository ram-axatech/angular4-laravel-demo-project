import { Component, OnInit, AfterContentInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../services/product.service';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit, AfterContentInit {
  public bViewActive = false;
  public productForm: FormGroup;
  public products;
  private iLoopVar: number;
  public error_msg: string;

  constructor(
   private fb: FormBuilder, private ps: ProductService,
   private login: LoginService
  ) {
    this.productForm = fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      category: ['', [Validators.required, Validators.minLength(3)]],
      price: ['', [Validators.required, Validators.min(5)]],
      id: ''
    });
  }

  ngOnInit() {
    this.login.initUser();
    this.ps.products().subscribe((response) => {
      this.products = response;
    });
  }

  ngAfterContentInit() {
    this.login.loginEvent.emit();
  }

  save() {
    this.bViewActive = true;
    let oData = this.productForm.value;
    if (oData.id !== '' && oData.id > 0) {
      this.update(oData);
    } else { // insert request
      this.create(oData);
    }
  }

  update(oData) {
    this.ps.update(oData).subscribe((response) => {
      if (response['status']) {
        this.products[this.iLoopVar] = oData;
      } else {
        this.error_msg = response['msg'];
      }
      this.reset();
      this.bViewActive = false;
    });
  }

  create(oData) {
    this.ps.create(oData).subscribe((response) => {
      if (response['status']) {
        oData.id = response['id'];
        this.products.push(oData);
        this.reset();
      } else {
        this.error_msg = response['msg'];
      }
      this.bViewActive = false;
    });
  }

  edit(product, index: number) {
    this.iLoopVar = index;
    this.bViewActive = false;
    this.productForm.setValue({
      name: product.name,
      category: product.category,
      price: product.price,
      id: product.id
    });
  }

  view(product, index: number) {
    this.bViewActive = true;
    this.productForm.setValue({
      name: product.name,
      category: product.category,
      price: product.price,
      id: product.id
    });
  }

  delete(product, index: number) {
    this.iLoopVar = index;
    this.ps.delete(product.id).subscribe((response) => {
      this.products.splice(index, 1);
      this.reset();
      this.bViewActive = false;
    });
  }

  reset() {
    this.productForm.setValue({
      name: '',
      category: '',
      price: '',
      id: ''
    });
  }

}
