import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  bIsValidLogin = true;
  loginForm: FormGroup;

  constructor(
    fb: FormBuilder, private ls: LoginService,
    private route: Router
  ) {
    this.loginForm = fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
  }

  submit() {
    let loginParams = this.loginForm.value;
    this.ls.authenticate(loginParams).subscribe((response) => {
      if (response['status']) {
        this.ls.createSession(response);
        if (response['role'] === 'admin') {
          this.route.navigate(['/products']);
        } else {
          this.route.navigateByUrl('/store');
          // this.route.navigate(['/store']);
        }
      } else {
        this.bIsValidLogin = false;
      }
    });
  }

}
