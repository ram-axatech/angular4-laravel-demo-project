<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('users')->insert([
          'name' => 'Admin',
          'email' => 'admin@admin.com',
          'role' => 'admin',
          'password' => Hash::make('admin1'),
          'created_at' => '2017-10-12 15:06:49'
      ]);

      DB::table('users')->insert([
          'name' => 'User',
          'email' => 'user@user.com',
          'role' => 'user',
          'password' => Hash::make('user12'),
          'created_at' => '2017-10-12 15:06:49'
      ]);
    }
}
