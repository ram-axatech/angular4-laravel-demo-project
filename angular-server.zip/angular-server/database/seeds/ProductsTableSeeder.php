<?php

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('products')->insert([
          'name' => 'Laptop',
          'category' => 'digital',
          'price' => 10000,
          'created_at' => '2017-10-12 15:06:49'
      ]);

      DB::table('products')->insert([
          'name' => 'Desktop',
          'category' => 'digital',
          'price' => 9000,
          'created_at' => '2017-10-12 15:06:49'
      ]);

      DB::table('products')->insert([
          'name' => 'Mobile',
          'category' => 'digital',
          'price' => 8000,
          'created_at' => '2017-10-12 15:06:49'
      ]);
    }
}
