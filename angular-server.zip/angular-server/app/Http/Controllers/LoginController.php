<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LoginValidate;
use App\User;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function authenticate(LoginValidate $request)
    {
      $aUser = [
        'status'=>false,
        'msg'=>'Invalid login username and password'
      ];
      $oUser = User::whereEmail($request->email)->first();
      if(
        !empty($oUser) &&
          Hash::check($request->password, $oUser->password)
      ) {
        $aUser = [
          'status'=>true,
          'name' => $oUser->name,
          'email' => $oUser->email,
          'role' => $oUser->role,
          'id' => $oUser->id
        ];
        //session($aUser);
      }
      return response($aUser);
    }
}
